Hi there!

Thanks for giving the first Version 'Attribute Manager' a go!


How to get started:
1. Open maya and open the script editor.
2. Drag and drop the 'Attribute_Manager.py' file into the python code section of the Script Editor (or copy the code over manually)
3. Run the code!
4. (Optional) Add it to a shelf and add the included Icon, so it's easy to find and reuse without needing the Script Editor.


On how to use the Attribute Manager:
Watch this Video here and you should have a good starting point!
https://youtu.be/18OTPJGTL9A


Warning!
There will be bugs as this is the Version 1 of this Tool. I would love to improve the tool further at some point so any recommendations or bugs can be reported to timon.holzer@outlook.com!